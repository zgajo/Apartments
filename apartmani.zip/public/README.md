Introduction
============

1. Website for Pranjić apartments landing page
2. Admin panel to track reservations

© Darko Pranjić

Used for creating:

Laravel
Vue.js + vuex
Chart.js


Frontend
============




Admin Panel
============


