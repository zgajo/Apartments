<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <title>Lanuncher Website Template | Home :: W3layouts</title>
        <link href="css/firstPage.css" rel="stylesheet" type="text/css"  media="all" />
        <meta name="keywords" content="Lanuncher iphone web template, Andriod web template, Smartphone web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
        <link href='//fonts.googleapis.com/css?family=Ropa+Sans' rel='stylesheet' type='text/css'>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    </head>
    <body>
        <!--start-wrap--->
            <div class="wrap">
                <!--start-header--->
                <div class="header">
                    <div style="margin-top:10px">
                        <ul>
                            <li><a href="https://www.facebook.com/appPranjic/"><img src="img/1486962055_facebook.png" title="Pranjic apartments Facebook profile" style="width:50px" /></a></li>
                            <div class="clear"> </div>
                        </ul>
                    </div>
                    <div class="clear"> </div>
                </div>
                <div class="content">
                    <div class="left-content">
                        <h4>this website is Under Mainteance, You will be redirected</h4>
                        <p>.</p>
                    </div>
                    <div class="right-content">
                        <img src="img/banner.png" title="banner-name" /> 
                    </div>
                    <div class="clear"> </div>
                </div>
                <div class="copy-right">
                </div>
                <!--end-header--->
            </div>
        <!--start-wrap--->
    </body>
    <script>
    $(document).ready(function(){
        $("a[title='Hosted on free web hosting 000webhost.com. Host your own website for FREE.']").hide()
        setTimeout(()=>{
            window.location = "https://www.facebook.com/appPranjic/"
        },3000)
    })
        
    </script>
</html>
